// script.js
// Hybrid SF Waymo estimator:
// - Part 1: Sensor layer (camera sampling + rough Waymo detection).
// - Part 2: Monte Carlo layer (fleet-based, trip-based, sensor-based).
// - Part 3: Blended estimate with adjustable weight on sensors.

let histogramChart = null;

// --- Sensor layer state ---
let cameras = [];
let sensorSampling = false;
let lastObservedDetections = 0;
let lastObservedCameras = 0;
let lastSensorCitywideEstimate = null;  // single point estimate
let sensorIntervalId = null;

// --- Initialize on DOM ready ---
document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("inputs-form");
  form.addEventListener("submit", handleFormSubmit);

  const toggleSensorButton = document.getElementById("toggleSensorButton");
  toggleSensorButton.addEventListener("click", toggleSensorSampling);

  // Try to load camera list once on startup.
  loadCameras();
  updateCoverageLabel();
});

/**
 * Load camera definitions from cameras.json.
 */
async function loadCameras() {
  const statusEl = document.getElementById("sensorStatus");
  try {
    statusEl.textContent = "Loading camera list...";
    const resp = await fetch("cameras.json");
    if (!resp.ok) {
      throw new Error(`Failed to fetch cameras.json (status ${resp.status})`);
    }
    const data = await resp.json();
    // Validate structure: expect an array of objects with a url.
    cameras = data.filter(cam => cam && typeof cam.url === "string" && cam.url.length > 0);
    statusEl.textContent = `Loaded ${cameras.length} cameras from cameras.json.`;
  } catch (err) {
    console.error(err);
    cameras = [];
    statusEl.textContent = `Error loading cameras.json: ${err.message}`;
  }
}

/**
 * Start or stop the periodic camera sampling.
 */
function toggleSensorSampling() {
  const button = document.getElementById("toggleSensorButton");
  const statusEl = document.getElementById("sensorStatus");

  if (!sensorSampling) {
    if (!cameras || cameras.length === 0) {
      statusEl.textContent = "No cameras loaded yet – check cameras.json.";
      return;
    }
    sensorSampling = true;
    button.textContent = "Stop camera sampling";
    statusEl.textContent = "Sampling cameras every 30 seconds...";
    // Run immediately, then periodically.
    sampleAllCameras();
    sensorIntervalId = setInterval(sampleAllCameras, 30000);
  } else {
    sensorSampling = false;
    button.textContent = "Start camera sampling";
    statusEl.textContent = "Camera sampling stopped.";
    if (sensorIntervalId !== null) {
      clearInterval(sensorIntervalId);
      sensorIntervalId = null;
    }
  }
}

/**
 * Update display of coverage fraction label.
 */
function updateCoverageLabel() {
  const coverageInput = document.getElementById("coverageFraction");
  const label = document.getElementById("coverageFractionLabel");
  const setLabel = () => {
    const v = Number(coverageInput.value);
    if (!Number.isNaN(v)) {
      label.textContent = v.toFixed(2);
    } else {
      label.textContent = "–";
    }
  };
  setLabel();
  coverageInput.addEventListener("input", setLabel);
}

/**
 * Fetch and process snapshots from all cameras (or a subset).
 */
async function sampleAllCameras() {
  const coverageInput = document.getElementById("coverageFraction");
  const coverage = Number(coverageInput.value);
  const statusEl = document.getElementById("sensorStatus");

  if (!cameras || cameras.length === 0) {
    statusEl.textContent = "No cameras to sample – cameras.json might be empty.";
    return;
  }
  if (Number.isNaN(coverage) || coverage <= 0 || coverage > 1) {
    statusEl.textContent = "Coverage fraction must be between 0 and 1.";
    return;
  }

  statusEl.textContent = "Sampling cameras...";
  let detections = 0;
  let usedCameras = 0;

  for (const cam of cameras) {
    if (!cam.url) continue;
    try {
      const count = await sampleSingleCamera(cam);
      detections += count;
      usedCameras += 1;
    } catch (err) {
      console.warn("Camera failed:", cam.id || cam.url, err);
    }
  }

  if (usedCameras === 0) {
    // Nothing usable this round: don't overwrite sensor estimate with 0.
    lastObservedDetections = 0;
    lastObservedCameras = 0;
    lastSensorCitywideEstimate = null;
    document.getElementById("observedDetections").textContent = "0";
    document.getElementById("observedCameras").textContent = "0";
    document.getElementById("sensorEstimate").textContent = "–";
    statusEl.textContent = "No cameras produced usable images in the last sample.";
    return;
  }

  lastObservedDetections = detections;
  lastObservedCameras = usedCameras;

  document.getElementById("observedDetections").textContent =
    detections.toLocaleString();
  document.getElementById("observedCameras").textContent =
    usedCameras.toLocaleString();

  // Simple scaling: if cameras see coverage fraction of citywide vehicles,
  // observedDetections ≈ totalVehicles * coverage
  const citywide = detections / coverage;
  lastSensorCitywideEstimate = citywide;

  document.getElementById("sensorEstimate").textContent =
    Number.isFinite(citywide) ? Math.round(citywide).toLocaleString() : "–";
  statusEl.textContent = `Last sample: ${detections} detections across ${usedCameras} cameras.`;
}

/**
 * Load a single camera image and run the Waymo-ish detector.
 * Returns approximate count (0 or 1+).
 */
async function sampleSingleCamera(cam) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => {
      try {
        const count = detectWaymoHeuristic(img);
        resolve(count);
      } catch (err) {
        reject(err);
      }
    };
    img.onerror = () => reject(new Error("Failed to load image"));
    // Cache-buster query param
    img.src = cam.url + (cam.url.includes("?") ? "&" : "?") + "t=" + Date.now();
  });
}

/**
 * Very rough heuristic detector for Waymo-like vehicles in an image.
 *
 * This is intentionally simple and readable. Later, you can replace this with
 * a TF.js model that does real object detection.
 */
function detectWaymoHeuristic(img) {
  // Draw image into an offscreen canvas.
  const canvas = document.createElement("canvas");
  const ctx = canvas.getContext("2d");

  // Downscale for speed.
  const targetWidth = 320;
  const aspect = img.height / img.width;
  canvas.width = targetWidth;
  canvas.height = Math.round(targetWidth * aspect);

  ctx.drawImage(img, 0, 0, canvas.width, canvas.height);

  const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
  const data = imageData.data;

  // Very crude heuristic:
  // 1. Count "white-ish" pixels (Waymos are usually white).
  // 2. Focus on lower half of image where road and cars are likely.
  // 3. Convert counts -> approximate vehicle count with a minimum density threshold.
  //
  // This will overcount in some scenes and undercount in others, but it gives
  // us a starting point that is strictly better than "pure vibes".

  let whitePixelCount = 0;
  const w = canvas.width;
  const h = canvas.height;

  for (let y = Math.floor(h * 0.4); y < h; y++) { // lower 60% of image
    for (let x = 0; x < w; x++) {
      const idx = (y * w + x) * 4;
      const r = data[idx];
      const g = data[idx + 1];
      const b = data[idx + 2];

      const brightness = (r + g + b) / 3;
      const maxChannel = Math.max(r, g, b);
      const minChannel = Math.min(r, g, b);

      const isBright = brightness > 180;
      const isLowSaturation = (maxChannel - minChannel) < 40;

      if (isBright && isLowSaturation) {
        whitePixelCount++;
      }
    }
  }

  // Require a minimum density of white pixels before calling anything a "car".
  if (whitePixelCount < 200) {
    return 0;
  }

  // Tunable parameter: approximate number of white-ish pixels per Waymo.
  const pixelsPerCarApprox = 800;
  const estimatedCars = whitePixelCount / pixelsPerCarApprox;

  if (estimatedCars < 0.5) return 0;
  if (estimatedCars < 1.5) return 1;
  return 2;
}

/**
 * Placeholder: if you later want to use a TF.js model, you can replace
 * detectWaymoHeuristic with something like this:
 *
 * async function detectWaymoWithModel(img) {
 *   const tensor = tf.browser.fromPixels(img)
 *       .resizeNearestNeighbor([320, 320])
 *       .expandDims(0)
 *       .toFloat()
 *       .div(255.0);
 *   const output = model.predict(tensor);
 *   const score = (await output.data())[0];
 *   return score > 0.6 ? 1 : 0;
 * }
 *
 * Then swap the call inside sampleSingleCamera.
 */

// ----------------- Monte Carlo layer -----------------

/**
 * Main handler when the user hits "Run Simulation".
 */
function handleFormSubmit(event) {
  event.preventDefault();

  const statusEl = document.getElementById("statusMessage");
  const runButton = document.getElementById("runButton");
  statusEl.textContent = "";
  runButton.disabled = true;

  try {
    const params = readInputs();
    const results = runMonteCarlo(params);

    updateTextResults(results);
    drawHistogram(results.blendedSamples);

    statusEl.textContent = `Simulation complete with ${params.samples.toLocaleString()} samples.`;
  } catch (err) {
    console.error(err);
    statusEl.textContent = `Error: ${err.message}`;
  } finally {
    runButton.disabled = false;
  }
}

/**
 * Reads and validates inputs from the DOM.
 */
function readInputs() {
  const fleetSize     = getNumber("fleetSize");
  const sfShareMinPct = getNumber("sfShareMin");
  const sfShareMaxPct = getNumber("sfShareMax");
  const utilMinPct    = getNumber("utilMin");
  const utilMaxPct    = getNumber("utilMax");
  const tripsPerDay   = getNumber("tripsPerDay");
  const tpcMin        = getNumber("tripsPerCarMin");
  const tpcMax        = getNumber("tripsPerCarMax");
  const samples       = Math.floor(getNumber("samples"));
  const sensorWeight  = Number(document.getElementById("sensorWeight").value);

  if (!isPositive(fleetSize)) {
    throw new Error("Fleet size must be > 0.");
  }
  if (!validRange(sfShareMinPct, sfShareMaxPct, 0, 100)) {
    throw new Error("SF share (%) must be between 0 and 100, with min ≤ max.");
  }
  if (!validRange(utilMinPct, utilMaxPct, 0, 100)) {
    throw new Error("Utilization (%) must be between 0 and 100, with min ≤ max.");
  }
  if (tripsPerDay < 0) {
    throw new Error("Trips per day cannot be negative.");
  }
  if (!validRange(tpcMin, tpcMax, 0, Infinity) || tpcMin === 0) {
    throw new Error("Trips per car per day must be > 0, with min ≤ max.");
  }
  if (samples < 1000) {
    throw new Error("Number of samples should be at least 1000.");
  }
  if (Number.isNaN(sensorWeight) || sensorWeight < 0 || sensorWeight > 1) {
    throw new Error("Sensor weight must be between 0 and 1.");
  }

  return {
    fleetSize,
    sfShareMin: sfShareMinPct / 100.0,
    sfShareMax: sfShareMaxPct / 100.0,
    utilMin:    utilMinPct / 100.0,
    utilMax:    utilMaxPct / 100.0,
    tripsPerDay,
    tripsPerCarMin: tpcMin,
    tripsPerCarMax: tpcMax,
    samples,
    sensorWeight
  };
}

function getNumber(id) {
  const value = Number(document.getElementById(id).value);
  if (Number.isNaN(value)) {
    throw new Error(`Input "${id}" is not a valid number.`);
  }
  return value;
}

function isPositive(x) {
  return x > 0;
}

function validRange(min, max, minAllowed, maxAllowed) {
  if (min < minAllowed || max < minAllowed) return false;
  if (maxAllowed !== Infinity && (min > maxAllowed || max > maxAllowed)) return false;
  if (min > max) return false;
  return true;
}

/**
 * Runs the Monte Carlo simulation.
 */
function runMonteCarlo(params) {
  const fleetSamples   = [];
  const tripSamples    = [];
  const sensorSamples  = [];
  const blendedSamples = [];

  const sensorPointEstimate = lastSensorCitywideEstimate;

  for (let i = 0; i < params.samples; i++) {
    const f = sampleFleetBased(params);
    const t = sampleTripBased(params);
    const s = sampleSensorBased(sensorPointEstimate);

    const blended = blendSamples(f, t, s, params.sensorWeight);

    fleetSamples.push(f);
    tripSamples.push(t);
    sensorSamples.push(s);
    blendedSamples.push(blended);
  }

  return {
    fleetSamples,
    tripSamples,
    sensorSamples,
    blendedSamples,
    fleetStats:   summarizeSamples(fleetSamples),
    tripStats:    summarizeSamples(tripSamples),
    sensorStats:  summarizeSamples(sensorSamples),
    blendedStats: summarizeSamples(blendedSamples)
  };
}

/**
 * Fleet-based sample.
 */
function sampleFleetBased(params) {
  const sfShare = randomUniform(params.sfShareMin, params.sfShareMax);
  const util    = randomUniform(params.utilMin, params.utilMax);
  const fleetInSF   = params.fleetSize * sfShare;
  const activeInSF  = fleetInSF * util;
  return activeInSF;
}

/**
 * Trip-based sample.
 */
function sampleTripBased(params) {
  if (params.tripsPerDay === 0) return 0;
  const tripsPerCar = randomUniform(params.tripsPerCarMin, params.tripsPerCarMax);
  return params.tripsPerDay / tripsPerCar;
}

/**
 * Sensor-based sample.
 * If we have a point estimate from cameras, treat it as Lognormal(mean, ~30% std dev).
 * If not, just return NaN and handle downstream (will be ignored in blending).
 */
function sampleSensorBased(sensorPointEstimate) {
  if (!Number.isFinite(sensorPointEstimate) || sensorPointEstimate <= 0) {
    return NaN;
  }

  const mean = sensorPointEstimate;
  const sd   = mean * 0.3; // 30% relative standard deviation

  // Convert desired mean/sd to lognormal parameters mu, sigma.
  const varianceRatio = (sd * sd) / (mean * mean);
  const sigma2 = Math.log(1 + varianceRatio);
  const sigma  = Math.sqrt(sigma2);
  const mu     = Math.log(mean) - 0.5 * sigma2;

  const z = randomNormal(0, 1);
  const sample = Math.exp(mu + sigma * z);

  return sample;
}

/**
 * Blend fleet, trip, sensor estimates.
 * If sensor is missing, weight collapses back to fleet/trip 50/50.
 */
function blendSamples(fleet, trip, sensor, sensorWeight) {
  const hasSensor = Number.isFinite(sensor);

  if (!hasSensor || sensorWeight === 0) {
    // Pure 2-way blend
    return 0.5 * fleet + 0.5 * trip;
  }

  const remaining = 1 - sensorWeight;
  const fleetWeight = remaining / 2;
  const tripWeight  = remaining / 2;

  return fleetWeight * fleet + tripWeight * trip + sensorWeight * sensor;
}

/**
 * Summarize samples with mean and 5th/95th percentiles.
 */
function summarizeSamples(samples) {
  const finite = samples.filter(x => Number.isFinite(x));
  if (finite.length === 0) {
    return { mean: NaN, p5: NaN, p95: NaN };
  }

  const sorted = [...finite].sort((a, b) => a - b);
  const n = sorted.length;
  const mean = sorted.reduce((sum, x) => sum + x, 0) / n;
  const p5   = percentile(sorted, 0.05);
  const p95  = percentile(sorted, 0.95);
  return { mean, p5, p95 };
}

function percentile(sortedArray, p) {
  const n = sortedArray.length;
  if (n === 0) return NaN;

  const index = p * (n - 1);
  const lower = Math.floor(index);
  const upper = Math.ceil(index);

  if (lower === upper) {
    return sortedArray[lower];
  }

  const weight = index - lower;
  return sortedArray[lower] * (1 - weight) + sortedArray[upper] * weight;
}

function randomUniform(min, max) {
  return min + (max - min) * Math.random();
}

/**
 * Box–Muller transform for Normal(mean, stdDev).
 */
function randomNormal(mean, stdDev) {
  let u1 = 0;
  let u2 = 0;
  // Avoid 0 for log
  while (u1 === 0) u1 = Math.random();
  while (u2 === 0) u2 = Math.random();
  const z0 = Math.sqrt(-2.0 * Math.log(u1)) * Math.cos(2.0 * Math.PI * u2);
  return mean + z0 * stdDev;
}

/**
 * Draw histogram for blended samples.
 */
function drawHistogram(samples) {
  const canvas = document.getElementById("histogramCanvas");
  const ctx = canvas.getContext("2d");

  const finite = samples.filter(x => Number.isFinite(x));
  if (finite.length === 0) {
    return;
  }

  const n = finite.length;
  const binCount = Math.min(40, Math.max(10, Math.floor(Math.sqrt(n))));

  const minVal = Math.min(...finite);
  const maxVal = Math.max(...finite);

  // Edge case: if all values are identical, create a single bin.
  if (maxVal === minVal) {
    const labels = [minVal.toFixed(0)];
    const bins = [finite.length];

    if (histogramChart) {
      histogramChart.destroy();
    }

    histogramChart = new Chart(ctx, {
      type: "bar",
      data: {
        labels,
        datasets: [{
          label: "Blended estimate frequency",
          data: bins
        }]
      },
      options: {
        responsive: true,
        scales: {
          x: {
            title: {
              display: true,
              text: "Estimated active Waymo vehicles in SF"
            }
          },
          y: {
            title: {
              display: true,
              text: "Number of samples"
            }
          }
        }
      }
    });

    return;
  }

  const binSize = (maxVal - minVal) / binCount;
  const bins = new Array(binCount).fill(0);
  const labels = [];

  for (let i = 0; i < binCount; i++) {
    const start = minVal + i * binSize;
    const end   = start + binSize;
    const mid   = (start + end) / 2;
    labels.push(mid.toFixed(0));
  }

  for (const value of finite) {
    let idx = Math.floor((value - minVal) / binSize);
    if (idx < 0) idx = 0;
    if (idx >= binCount) idx = binCount - 1;
    bins[idx] += 1;
  }

  if (histogramChart) {
    histogramChart.destroy();
  }

  histogramChart = new Chart(ctx, {
    type: "bar",
    data: {
      labels,
      datasets: [{
        label: "Blended estimate frequency",
        data: bins
      }]
    },
    options: {
      responsive: true,
      scales: {
        x: {
          title: {
            display: true,
            text: "Estimated active Waymo vehicles in SF"
          }
        },
        y: {
          title: {
            display: true,
            text: "Number of samples"
          }
        }
      }
    }
  });
}

/**
 * Update UI results.
 */
function updateTextResults(results) {
  setResult("fleetMean",   results.fleetStats.mean);
  setResult("fleetRange",  results.fleetStats.p5, results.fleetStats.p95);

  setResult("tripMean",    results.tripStats.mean);
  setResult("tripRange",   results.tripStats.p5, results.tripStats.p95);

  setResult("sensorMean",  results.sensorStats.mean);
  setResult("sensorRange", results.sensorStats.p5, results.sensorStats.p95);

  setResult("blendMean",   results.blendedStats.mean);
  setResult("blendRange",  results.blendedStats.p5, results.blendedStats.p95);
}

function setResult(id, valueOrMin, maybeMax) {
  const el = document.getElementById(id);
  if (!el) return;

  if (maybeMax === undefined) {
    el.textContent = formatNumber(valueOrMin);
  } else {
    el.textContent = `${formatNumber(valueOrMin)} – ${formatNumber(maybeMax)}`;
  }
}

function formatNumber(x) {
  if (!Number.isFinite(x)) return "–";
  return Math.round(x).toLocaleString();
}
