SF Waymo Estimator (Hybrid)
===========================

This repo is a static GitHub Pages dashboard that estimates how many Waymo
vehicles are active in San Francisco on a typical day.

It combines three pieces of information:
1. Fleet-based assumptions (Bay Area fleet size, SF share, utilization)
2. Trip-based assumptions (trips per day, trips per car)
3. Live camera observations (from traffic cameras listed in cameras.json)

How to use
----------

1. Put these files in a GitHub repo (for example: sf-waymo-estimator):

   - index.html
   - style.css
   - script.js
   - cameras.json

2. Edit cameras.json to contain real traffic camera JPEG URLs that:
   - Are reachable from the browser, and
   - Ideally send CORS headers (Access-Control-Allow-Origin: *)

3. Enable GitHub Pages in the repo settings:
   - Settings -> Pages -> Source: "Deploy from a branch"
   - Branch: main (or master), folder: root (/)

4. Visit the published URL, for example:
   https://your-username.github.io/sf-waymo-estimator

Notes
-----

- The "Waymo detector" is a simple white-pixel heuristic in script.js
  (detectWaymoHeuristic). You can later replace this with a real TensorFlow.js
  model if you want more accurate detections.

- If cameras do not support CORS, the browser will refuse to read pixels for
  security reasons. In that case you will see repeated "camera failed" messages
  in the console. To fix that, you can point cameras.json at a proxy that
  does add CORS headers.

- The Monte Carlo model is intentionally transparent and easy to modify. Look
  for runMonteCarlo, sampleFleetBased, sampleTripBased, and sampleSensorBased
  in script.js if you want to change any of the assumptions.
